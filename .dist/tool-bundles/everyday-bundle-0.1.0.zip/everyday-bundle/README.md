# Everyday Bundle

Bundle of day-to-day tools for notes and quick utility lookups.

Included tools:
- `notion`
- `weather`
